<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>---== Cãopartilhe ==---</title> 
<meta charset="UTF-8">
<meta http-equiv="Expires" CONTENT="0">
<meta http-equiv="Cache-Control" CONTENT="no-cache, must-revalidate">
<meta http-equiv="Pragma" CONTENT="no-cache">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> 
<meta name="title" CONTENT="Cãopartilhe">
<meta name="description" CONTENT="Site de divulgação de uma ONG em defesa dos direitos e cuidados de animais">
<meta name="keywords" CONTENT="Cãopartilhe">
<meta name="generator" content="Dreamweaver CS6, Netbeans 7.4">
<meta name="author" CONTENT="Deville comunicação">
<meta name="distribution" content="Global" />
<meta name="robots" CONTENT="index,follow">
<meta name="rating" content="Geral" />
<meta name="expires" content="0" />
<meta name="charset" content="ISO-8859-1" />
<meta name="SEO - Search Engine Otimization" content="www.villeklemens.com.br" />
<meta name="revisit-after" content="1 Day" />
<meta name="copyright" content="www.villeklemens.com.br" />
<meta name="OWNER" content="www.villeklemens.com.br" />
<meta name="publisher" content="www.villeklemens.com.br" />
<meta name="copyright" content="Copyright 2015 -" />
<meta name="rating" content="General" />
<meta name="language" content="pt-BR, portuguese" />
<meta name="GOOGLEBOT" content="INDEX, FOLLOW" />
<meta name="MSNBot" content="INDEX, FOLLOW" />
<meta name="yahooBot" content="INDEX, FOLLOW" />
<meta name="cuilBot" content="INDEX, FOLLOW" />
<meta name="SERVICE" content="descrição 4" />
<meta name="CATEGORY" content="descrição 5" />
<meta name="city" content="all" />
<meta name="country" content="BR" />
<meta name="coverage" content="Worldwide" />
 	
<!-- Start WOWSlider.com HEAD section -->
<link rel="stylesheet" type="text/css" href="/caopartilhe.org.br/web/engine1/style.css" />
<script type="text/javascript" src="/caopartilhe.org.br/web/engine1/jquery.js"></script>
<!-- End WOWSlider.com HEAD section -->

<link rel="shortcut icon" href="/caopartilhe.org.br/web/img/indice.ico" type="image/x-icon" />
<link rel="stylesheet" type="text/css" href="/caopartilhe.org.br/web/css/csss_style.css" /> 
<link rel="stylesheet" type="text/css" href="/caopartilhe.org.br/web/css/default.css" /> 
<link rel="stylesheet" type="text/css" href="/caopartilhe.org.br/web/css/estilo.css" /> 
<link rel="stylesheet" type="text/css" href="/caopartilhe.org.br/web/css/ie.css" /> 
<link rel="stylesheet" type="text/css" href="/caopartilhe.org.br/web/css/nanoscroller.css" />
<link rel="stylesheet" type="text/css" href="/caopartilhe.org.br/web/css/nanostyle.css" />

<script type="text/javascript" src="/caopartilhe.org.br/web/js/ie-hack.js"> </script>
<script type="text/javascript" src="/caopartilhe.org.br/web/js/html5.js"> </script>
<script type="text/javascript" src="/caopartilhe.org.br/web/js/ajax.js"></script>
<script language="javascript" src="/caopartilhe.org.br/web/js/jquery-2.1.0.js"></script>
<script type="text/javascript" src="/caopartilhe.org.br/web/js/instrucao.js"></script>
<script type="text/javascript" src="/caopartilhe.org.br/web/js/maskedinput.js"></script>
<script type="text/javascript" src="/caopartilhe.org.br/web/engine1/wowslider.js"></script>
<script type="text/javascript" src="/caopartilhe.org.br/web/engine1/script.js"></script>
<script type="text/javascript" src="/caopartilhe.org.br/web/js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="/caopartilhe.org.br/web/js/jquery.nanoscroller.min.js"></script>

</head>
<body>
<div id="page">
<div align=center id="head" >
  <div align=center id="Imagemenu">
  
    <div style="//border: 1px solid black;position:relative;left:-375px;top:25px;width:105px;height:109px;top:5px;">
      <a href="index.html"><img src="img/Marca-Caopartilhe.png"></a>
    </div>

    <div id="headerdata">
      <div align=left style="//border: 1px solid red;position:relative;float:left;width:100px;top:10px;">
        <h style="font-size:12px;color:#710c07"><strong>31 98785-0731</strong></h>
      </div>
      <div align=left style="//border: 1px solid red;position:relative;float:left;width:175px;left:30px;top:10px;">
        <h style="font-size:12px;color:#710c07">caopartilhe@caopartilhe.com.br</h>
      </div>
      <div align=left style="//border: 1px solid red;position:relative;float:left;width:32px;left:40px;">
        <a href="https://www.facebook.com/caopartilhe" target="_blank"><img src="img/icon_facebook.png" border=0></a> 
      </div>
    </div>
      <nav id="header-navigation">
      <ul class="menu" > 
	      <li style="width:105px;"><a href="#" onclick="abrirPag('quemsomos.html');">QUEM SOMOS</a></li>
	      <li style="width:135px;"><a href="#" >FAÇA A DIFERENÇA</a>
        <ul >
	          <li class="has-sub"><a href="#" onclick="abrirPag('ajudar.html');"><h class="lblh">QUERO AJUDAR</h></a></li>
	          <li class="has-sub"><a href="#" onclick="abrirPag('adotar.html');"><h class="lblh">QUERO ADOTAR</h></a></li>
        </ul>
        </li>
        <li style="width:160px;"><a href="#" onclick="abrirPag('contas.html');">PRESTAÇÃO DE CONTAS</a></li>
	      <li style="width:60px;"><a href="#" onclick="abrirPag('fotos.html');">FOTOS</a></li>
	      <li style="width:90px;"><a href="#" onclick="abrirPag('parceiros.html');">PARCEIROS</a></li>
	      <li style="width:75px;"><a href="#" onclick="abrirPag('contato.html');">CONTATO</a></li>
      </ul>
      </nav>
  </div>		
</div> 

<div align=center id="context" >  
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
 <div id="container"> 
  <div id="primaryContent">
 <p><?php the_content(); ?>
</p> 
</div> </div> 
<?php endwhile;?>
<?php endif; ?> 
 
</div>
<div align=center id="footer" >
     <div style="//border: 1px solid red;background:url(/caopartilhe.org.br/web/img/ong-caopartilhe-rodape.jpg);background-color:#c9d1d8;font-size:12px;color:#710c07;position:relative;width:850px;height:90px;">
        <div align=center style="//border: 1px solid blue;position:relative;float:left;left:70px;width:66px;height:70px;top:10px;">
          <img src="/caopartilhe.org.br/web/img/ong-caopartilhe-marca-rodape.png">
        </div>
        <div align=left style="//border: 1px solid blue;position:relative;float:left;left:120px;width:230px;height:40px;top:30px;">
          Tudo que ele precisa é de amor.
          <br>Tudo que voce precisa é de amar!
        </div>
        <div align=right style="//border: 1px solid blue;position:relative;float:left;left:250px;width:240px;height:40px;top:30px;">
          Você pode fazer a diferença.
          <br>Seja um colaborador da Cãopartilhe!
        </div>
     </div>
</div>
</body>
</html>



